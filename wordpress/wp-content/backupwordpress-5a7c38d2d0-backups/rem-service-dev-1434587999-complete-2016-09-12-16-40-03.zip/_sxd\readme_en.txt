Installing

1.Unzip it and upload the contents of the directory to the server.
2.Set chmod 777 for �backup� directory.
3.Set chmod 666 for files �cfg.php� and �ses.php�.

Using

1.Open an URL http://domain.com/sxd/ in browser.
2.Enter the username and password for your database.
Please report problems and bugs to the forum, indicating your versions of browser, php and mysql.
